const makeJestConfig = require('../../configs/jestConfig');

module.exports = makeJestConfig(__dirname);
