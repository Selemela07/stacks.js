# @stacks/common

Common utilities used by Stacks.js packages.

## Installation

```
npm install @stacks/common
```
