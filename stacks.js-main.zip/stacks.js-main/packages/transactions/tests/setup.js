const fetchMock = require('jest-fetch-mock');
fetchMock.enableFetchMocks();