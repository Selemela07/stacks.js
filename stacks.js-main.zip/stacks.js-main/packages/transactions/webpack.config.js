const config = require('../../configs/webpack.config.js');

config.output.library.name = 'StacksTransactions';

config.resolve.fallback = {};

module.exports = config;
