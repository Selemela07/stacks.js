---
name: Feature request
about: Suggest an idea for this project
labels: 'feature'
title: ''
assignees: ''
---

### Problem

<!-- Is the feature related to a problem? E.g. I'm always frustrated when... -->

### Solution

<!-- How would you like the problem to be solved? If any ideas come to mind... -->

### Additional context

<!-- If applicable, add console logs, screenshots, or anything else to help explain the problem -->
